import { combineReducers } from 'redux';

export default combineReducers({
  replaceMe: () => 'hi there'
});
