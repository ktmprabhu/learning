import React from 'react';

const StreamEdit = () => {
  return <div>StreamEdit</div>;
};

export default StreamEdit;
