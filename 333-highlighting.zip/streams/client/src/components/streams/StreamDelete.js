import React from 'react';

const StreamDelete = () => {
  return <div>StreamDelete</div>;
};

export default StreamDelete;
